
%%%%%%%%%%%%% PARAMETERS THAT CAN BE SET UP BY THE USER %%%%%%%%%%%%%%%%

%% RF HEATING II
path_program = "C:\Users\sheyl\OneDrive - Danmarks Tekniske Universitet\DTU\Special course MRI\special-course-mri";
path_raw_data = "C:\Users\sheyl\OneDrive - Danmarks Tekniske Universitet\DTU\Special course MRI\special-course-mri\data\raw\RF heating II";
path_processed_data = "C:\Users\sheyl\OneDrive - Danmarks Tekniske Universitet\DTU\Special course MRI\special-course-mri\data\processed";
data = '\LOCALIZER*';
idx = 'RF_heating_II';
idx_balloon = 'balloon';
idx_tube = 'tube';